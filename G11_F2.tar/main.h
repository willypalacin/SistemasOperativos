#ifndef _main_H
#define _main_H

#include "structures.h"

User * MAIN_getUser();

#endif
